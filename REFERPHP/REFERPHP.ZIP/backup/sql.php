<?
$myserver = "server (usually localhost)";
$mylogin = "login";
$mypass = "password";
$mydb = "your database";
//DONT EDIT BELOW HERE
mysql_connect($myserver,$mylogin,$mypass);
mysql_select_db($mydb);
?>