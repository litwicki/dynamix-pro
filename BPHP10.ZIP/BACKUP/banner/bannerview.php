<?php
$clickf = "http://www.yourname.com/path/to/clicks.txt";
$viewf = "http://www.yourname.com/path/to/views.txt";
$urlf = "http://www.yourname.com/path/to/urls.txt";
$namef = "http://www.yourname.com/path/to/names.txt";
$clickarray = file($clickf);
$viewarray = file($viewf);
$urlarray = file($urlf);
$namearray = file($namef);
if ($action == "" && $id == "") {
	mt_srand ((double) microtime() * 1000000);
	$amount = count($namearray)-1;
	if ($amount <= 0) { $id = 0; }
	if ($amount > 0) { $id = mt_rand(0, $amount); }
	$fd = fopen ($viewf, "w");
		for ($i = 0; $i <=count($namearray); $i++) {
			$calc = $viewarray[$i]+1;
			if ($id == $i) { fwrite ($fd, "$calc\n"); }
			if ($id != $i) { fwrite ($fd, $viewarray[$i]); }
		}
	fclose($fd);
	echo "<a href=http://www.yourname.com/path/to/banner.php?action=click&id=$id><img src=\"http://www.yourname.com/path/to/banner/images/$id.gif\" border=0></a>";
}
?>