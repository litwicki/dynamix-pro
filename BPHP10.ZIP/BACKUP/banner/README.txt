________________________________________

BannerPHP v1.0
Copyright (c) 2001
DynamixPro - http://www.dynamixpro.com
________________________________________

BannerPHP is a banner rotation script that tracks
both views (impressions), and clicks, on any given
banner/image.  BannerPHP supports images of any size,
making it one of the most versatile, easy to use
scripts available.  For information on licensing bPHP
visit http://www.dynamixpro.com


**********
INSTALLING
**********

-------
STEP 1. 
-------
Open your PHP pages that you want the Banner 
on and put the line following in the space 
where you want the banner to be at on your page.
<?php include("bannerview.php"); ?>
Where the filename is you can put a directory name in 
front of that if the banner script is in a different
directory. (EX: "banner/bannerview.php")

-------
STEP 2.
-------
Open password.txt and enter your desired password.

-------
STEP 3.
-------
Upload all of your files to http://yourdomain.com/bPHP/
and then CHMOD all of the .txt files to 600.  (ONLY read
access).

-------
STEP 4.
-------
Call up http://yourdomain.com/bPHP/admin.php in your browser.
Set all of your banners you would like to rotate.
In the admin.php file you can also view statistics (views/clicks)
on each image, delete images, and edit current images.


***************
TROUBLESHOOTING
***************
For troubleshooting and help regarding bPHP, visit the Tech Forums
at http://www.dynamixpro.com/help/


******
AUTHOR
******
Ryan Meyers
ryan@dynamixpro.com
Programmer/Developer